# לוח קורס על-בסיסי גריאטריה — GitHub Pages

החבילה כוללת שני קבצים שחייבים להישאר באותה תיקייה:

- `index.html` — האתר עצמו.
- `schedule.json` — מקור הנתונים היחיד של מערכת השעות.

## העלאה ל-GitHub

1. צור Repository חדש ב-GitHub (למשל `geriatrics-course`).
2. העלה אליו את `index.html` ואת `schedule.json` לתיקייה הראשית.
3. ב-GitHub עבור אל **Settings → Pages**.
4. תחת **Build and deployment** בחר **Deploy from a branch**.
5. בחר `main` ו-`/ (root)` ושמור.
6. לאחר שהאתר פורסם, שלח לכולם את כתובת ה-GitHub Pages בלבד.

## איך עורכים את הלו״ז

באתר לחץ על **🔒 ניהול ב-GitHub**. האתר מזהה אוטומטית את שם המשתמש ואת ה-Repository מכתובת GitHub Pages ופותח את `schedule.json` במצב עריכה.

GitHub הוא שכבת ההרשאות: רק חשבון שיש לו Write access ל-Repository יכול לבצע Commit שמשנה את האתר החי. אין סיסמה בתוך קוד ה-HTML.

לאחר עריכה לחץ **Commit changes**. בפתיחה/רענון הבא של האתר הקובץ `schedule.json` נטען מחדש ולכן כולם יראו את העדכון.

## מבנה שיעור ב-schedule.json

```json
"2026-09-24": {
  "cat": "study",
  "catName": "ימי לימוד",
  "title": "יום לימודים",
  "lead": "ניהול הטיפול — משה אליהו",
  "time": "08:00–16:45",
  "place": "",
  "dow": "ה",
  "date": "24.09.26",
  "slots": [
    {
      "t": "15:15–16:45",
      "s": "ניהול הטיפול, תכנון ויישום התערבות סיעודית",
      "w": "משה אליהו"
    }
  ]
}
```

קטגוריות נתמכות: `study`, `practice`, `acls`, `sim`, `exam`.

## הערה חשובה

אם אתה משתמש בכתובת GitHub Pages רגילה (`username.github.io/repository`) אין צורך להגדיר ידנית owner/repo. אם בעתיד תעבור לדומיין מותאם אישית, ניתן למלא את `meta.github.owner` ו-`meta.github.repo` בתוך `schedule.json`.
